package com.example.method.worksurge.Enum;

/**
 * Created by Method on 1/6/2016.
 */
public enum IntentEnum {
    FOUND_SINGLE_VACANCY,
    FOUND_MULTIPLE_VACANCIES,
    FOUND_MULTIPLE_MAP_VACANCIES,
    DECISION,
    CONTEXT,
};
