package com.example.method.worksurge.Enum;

/**
 * Created by Method on 1/8/2016.
 */
// TODO: Make them type-safe
public enum FragmentEnum {
    LIST,
    MAP,
};
